<?php
include 'connect.php';
define('UPLPATH', '');
?>

<!DOCTYPE html>
<html>
<head>
  <title>MOPO</title>
  <link rel="stylesheet" type="text/css" href="style.css?v=3">
</head>
<body>

  <header>
      <img src="naslov.png">
    <div class="small-titles">
      <h2 class="small-title"><a href="index.php">HOME</a></h2>
      <h2 class="small-title"><a href="kategorija.php?category=Reise">REISE</a></h2>
      <h2 class="small-title"><a href="kategorija.php?category=Verbraucher">VERBRAUCHER</a></h2>
      <h2 class="small-title"><a href="administrator.php">ADMINISTRACIJA</a></h2>
      <h2 class="small-title"><a href="unos.php">UNOS</a></h2>
      <h2 class="small-title"><a href="registracija.php">REGISTRACIJA</a></h2>
    </div>
  </header>
  <hr>

  <section>
    <h2 class="section-title">REISE</h2>
    <hr class="crtica">
    <div class="row">
      <?php
      $query = "SELECT * FROM vijesti WHERE arhiva=0 AND kategorija='Reise' LIMIT 3";
      $result = mysqli_query($dbc, $query);
      $i = 1;
      while ($row = mysqli_fetch_array($result)) :
      ?>
        <a href="clanak.php?id=<?php echo $row['id']; ?>" class="box-link">
          <div class="box">
            <img src="<?php echo UPLPATH . $row['slika']; ?>" alt="Article <?php echo $i; ?>">
            <div class="article-content">
              <p class="mnaslov"><?php echo $row['sazetak']; ?></p>
            </div>
          </div>
        </a>
      <?php
        $i++;
      endwhile;
      ?>
    </div>
  
    <h2 class="section-title">VERBRAUCHER</h2>
    <hr class="crtica">
    <div class="row">
      <?php
      $query = "SELECT * FROM vijesti WHERE arhiva=0 AND kategorija='Verbraucher' LIMIT 3";
      $result = mysqli_query($dbc, $query);
      $i = 1;
      while ($row = mysqli_fetch_array($result)) :
      ?>
        <a href="clanak.php?id=<?php echo $row['id']; ?>" class="box-link">
          <div class="box">
            <img src="<?php echo UPLPATH . $row['slika']; ?>" alt="Article <?php echo $i; ?>">
            <div class="article-content">
            <p class="mnaslov"><?php echo $row['sazetak']; ?></p>
            </div>
          </div>
        </a>
      <?php
        $i++;
      endwhile;
      ?>
    </div>
  </section>

  <footer>
    <p>Copyright 2019 Morgenpost Verlad GmbH</p>
  </footer>
</body>
</html>
