<?php
include 'connect.php';
define('UPLPATH', '');


if (isset($_GET['id'])) {
  $articleID = $_GET['id'];
} else {

  header("Location: index.php");
  exit();
}


$query = "SELECT * FROM vijesti WHERE id = '$articleID'";
$result = mysqli_query($dbc, $query);


if (mysqli_num_rows($result) == 0) {
  header("Location: index.php");
  exit();
}

$row = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html>
<head>
  <title>MOPO</title>
  <link rel="stylesheet" type="text/css" href="style.css?v=3">
</head>
<body>
<header>
      <img src="naslov.png">
    <div class="small-titles">
      <h2 class="small-title"><a href="index.php">HOME</a></h2>
      <h2 class="small-title"><a href="kategorija.php?category=Reise">REISE</a></h2>
      <h2 class="small-title"><a href="kategorija.php?category=Verbraucher">VERBRAUCHER</a></h2>
      <h2 class="small-title"><a href="administrator.php">ADMINISTRACIJA</a></h2>
      <h2 class="small-title"><a href="unos.php">UNOS</a></h2>
      <h2 class="small-title"><a href="registracija.php">REGISTRACIJA</a></h2>
    </div>
  </header>
  <hr>
<div class="clanak">
  <div class="page-section">
    <h2 class="page-title"><?php echo $row['naslov']; ?></h2>
    <div class="kutija">
      <p class="kutija_tekst"> <?php echo $row['datum']; ?></p>
    </div>
    <div class="red">
      <div class="picture-container">
        <img src="<?php echo UPLPATH . $row['slika']; ?>" alt="Article Image">
      </div>
      <div class="text-container">
        <p class="content-text"><?php echo $row['sazetak']; ?></p>
      </div>
    </div>
   
    <div class="multi-line-text">
      <?php echo $row['tekst']; ?>
    </div>
  </div>
</div>
  <footer>
    <p>Copyright 2019 Morgenpost Verlad GmbH</p>
  </footer></body>
</html>
