<?php
date_default_timezone_set('Europe/Paris');

include 'connect.php';

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $picture = $_FILES['pphoto']['name'];
  $title = $_POST['title'];
  $about = $_POST['about'];
  $content = $_POST['content'];
  $category = $_POST['category'];
  $date = date('d.m.Y.');

  if (isset($_POST['archive'])) {
    $archive = 1;
  } else {
    $archive = 0;
  }

  $target_dir = $picture;
  move_uploaded_file($_FILES["pphoto"]["tmp_name"], $target_dir);

  $query = "INSERT INTO Vijesti (datum, naslov, sazetak, tekst, slika, kategorija, arhiva)
            VALUES ('$date', '$title', '$about', '$content', '$picture', '$category', '$archive')";

  $result = mysqli_query($dbc, $query) or die('Error querying database.');

}
?>

<!DOCTYPE html>
<html>
<head>
  <title>MOPO</title>
  <link rel="stylesheet" type="text/css" href="style.css?v=3">
  <script>
    function validateForm() {
      var title = document.forms["myForm"]["title"].value;
      var about = document.forms["myForm"]["about"].value;
      var content = document.forms["myForm"]["content"].value;
      var pphoto = document.forms["myForm"]["pphoto"].value;
      var category = document.forms["myForm"]["category"].value;

      if (title.length < 5 || title.length > 30) {
        document.getElementById("title").style.borderColor = "red";
        return false;
      }

      if (about.length < 10 || about.length > 100) {
        document.getElementById("about").style.borderColor = "red";
        return false;
      }

      if (content.trim() === "") {
        document.getElementById("content").style.borderColor = "red";
        return false;
      }

      if (pphoto === "") {
        document.getElementById("pphoto").style.borderColor = "red";
        return false;
      }

      if (category === "") {
        document.getElementById("category").style.borderColor = "red";
        return false;
      }
    }
  </script>
</head>
<body>
<header>
      <img src="naslov.png">
    <div class="small-titles">
      <h2 class="small-title"><a href="index.php">HOME</a></h2>
      <h2 class="small-title"><a href="kategorija.php?category=Reise">REISE</a></h2>
      <h2 class="small-title"><a href="kategorija.php?category=Verbraucher">VERBRAUCHER</a></h2>
      <h2 class="small-title"><a href="administrator.php">ADMINISTRACIJA</a></h2>
      <h2 class="small-title"><a href="unos.php">UNOS</a></h2>
      <h2 class="small-title"><a href="registracija.php">REGISTRACIJA</a></h2>
    </div>
  </header>
  <hr>

  <form name="myForm" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" enctype="multipart/form-data" onsubmit="return validateForm()">
    <div class="form-item">
      <label for="title">Naslov vijesti</label>
      <div class="form-field">
        <input type="text" name="title" id="title" class="form-field-textual">
      </div>
    </div>
    <div class="form-item">
      <label for="about">Kratki sadržaj vijesti (10 do 100 znakova)</label>
      <div class="form-field">
        <textarea name="about" id="about" cols="30" rows="10" class="formfield-textual"></textarea>
      </div>
    </div>
    <div class="form-item">
      <label for="content">Sadržaj vijesti</label>
      <div class="form-field">
        <textarea name="content" id="content" cols="30" rows="10" class="form-field-textual"></textarea>
      </div>
    </div>
    <div class="form-item">
      <label for="pphoto">Slika:</label>
      <div class="form-field">
        <input type="file" accept="image/jpg" class="input-text" name="pphoto" id="pphoto" />
      </div>
    </div>
    <div class="form-item">
      <label for="category">Kategorija vijesti</label>
      <div class="form-field">
        <select name="category" id="category" class="form-field-textual">
          <option value="">Odaberi kategoriju</option>
          <option value="Reise">REISE</option>
          <option value="Verbraucher">VERBRAUCHER</option>
        </select>
      </div>
    </div>
    <div class="form-item">
      <label>Spremiti u arhivu:</label>
      <div class="form-field">
        <input type="checkbox" name="archive">
      </div>
    </div>
    <div class="form-item">
      <button type="reset" value="Poništi">Poništi</button>
      <button type="submit" value="Prihvati">Prihvati</button>
    </div>
  </form>

  <footer>
  <p>Copyright 2019 Morgenpost Verlad GmbH</p>
  </footer>
</body>
</html>
