-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Računalo: localhost
-- Vrijeme generiranja: Lip 26, 2023 u 07:41 PM
-- Verzija poslužitelja: 5.1.41
-- PHP verzija: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Baza podataka: `mopo`
--

-- --------------------------------------------------------

--
-- Tablična struktura za tablicu `korisnik`
--

CREATE TABLE IF NOT EXISTS `korisnik` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ime` varchar(32) CHARACTER SET latin2 COLLATE latin2_croatian_ci NOT NULL,
  `prezime` varchar(32) CHARACTER SET latin2 COLLATE latin2_croatian_ci NOT NULL,
  `korisnicko_ime` varchar(32) CHARACTER SET latin2 COLLATE latin2_croatian_ci NOT NULL,
  `lozinka` varchar(255) CHARACTER SET latin2 COLLATE latin2_croatian_ci NOT NULL,
  `razina` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `korisnicko_ime` (`korisnicko_ime`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Izbacivanje podataka za tablicu `korisnik`
--

INSERT INTO `korisnik` (`id`, `ime`, `prezime`, `korisnicko_ime`, `lozinka`, `razina`) VALUES
(1, 'Gabrijel', 'Cindrić', 'Cindra', '$2a$07$usesomesillystringforeh6tvwDNOAiEn9PYXfY79K3vDiKj6Ib6', 1);

-- --------------------------------------------------------

--
-- Tablična struktura za tablicu `vijesti`
--

CREATE TABLE IF NOT EXISTS `vijesti` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datum` varchar(32) CHARACTER SET latin2 COLLATE latin2_croatian_ci NOT NULL,
  `naslov` varchar(64) CHARACTER SET latin2 COLLATE latin2_croatian_ci NOT NULL,
  `sazetak` text CHARACTER SET latin2 COLLATE latin2_croatian_ci NOT NULL,
  `tekst` text CHARACTER SET latin2 COLLATE latin2_croatian_ci NOT NULL,
  `slika` varchar(64) CHARACTER SET latin2 COLLATE latin2_croatian_ci NOT NULL,
  `kategorija` varchar(64) CHARACTER SET latin2 COLLATE latin2_croatian_ci NOT NULL,
  `arhiva` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Izbacivanje podataka za tablicu `vijesti`
--

INSERT INTO `vijesti` (`id`, `datum`, `naslov`, `sazetak`, `tekst`, `slika`, `kategorija`, `arhiva`) VALUES
(1, '26.06.2023.', 'Lorem ipsum dolor', 'Lorem ipsum dolor sit amet, consectetuer adipiscinLorem ipsum dolor sit amet, consectetuer adipiscin', 'Lorem ipsum dolor sit amet, consectetuer adipiscin', 'cetvrto.jpg', 'Reise', 0),
(2, '26.06.2023.', 'Lorem ipsum dolor', 'Lorem ipsum dolor sit amet, consectetuer adipiscinLorem ipsum dolor sit amet, consectetuer adipiscin', 'Lorem ipsum dolor sit amet, consectetuer adipiscin', 'peto.jpg', 'Reise', 0),
(3, '26.06.2023.', 'Lorem ipsum', 'Lorem ipsum dolor sit amet, consectetuer adipiscinLorem ipsum dolor sit amet, consectetuer adipiscin', 'Lorem ipsum dolor sit amet, consectetuer adipiscin', 'sesto.jpg', 'Reise', 0),
(4, '26.06.2023.', 'Lorem ipsum', 'Lorem ipsum dolor sit amet, consectetuer adipiscinLorem ipsum dolor sit amet, consectetuer adipiscin', 'Lorem ipsum dolor sit amet, consectetuer adipiscin', 'trece.jpg', 'Verbraucher', 0),
(5, '26.06.2023.', 'Lorem ipsum', 'Lorem ipsum dolor sit amet, consectetuer adipiscinLorem ipsum dolor sit amet, consectetuer adipiscin', 'Lorem ipsum dolor sit amet, consectetuer adipiscin', 'drugo.jpg', 'Verbraucher', 0),
(6, '26.06.2023.', 'Lorem ipsum dolor sit', 'Lorem ipsum dolor sit amet, consectetuer adipiscinLorem ipsum dolor sit amet, consectetuer adipiscin', 'Lorem ipsum dolor sit amet, consectetuer adipiscin', 'prvo.jpg', 'Verbraucher', 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
