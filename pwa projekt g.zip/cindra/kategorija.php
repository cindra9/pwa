<?php
include 'connect.php';
define('UPLPATH', '');


if (isset($_GET['category'])) {
  $category = $_GET['category'];
} else {

  $category = 'Reise';
}


$query = "SELECT * FROM vijesti WHERE arhiva = 0 AND kategorija = '$category'";
$result = mysqli_query($dbc, $query);
?>

<!DOCTYPE html>
<html>
<head>
  <title>MOPO</title>
  <link rel="stylesheet" type="text/css" href="style.css?v=3">
</head>
<body>
<header>
      <img src="naslov.png">
    <div class="small-titles">
      <h2 class="small-title"><a href="index.php">HOME</a></h2>
      <h2 class="small-title"><a href="kategorija.php?category=Reise">REISE</a></h2>
      <h2 class="small-title"><a href="kategorija.php?category=Verbraucher">VERBRAUCHER</a></h2>
      <h2 class="small-title"><a href="administrator.php">ADMINISTRACIJA</a></h2>
      <h2 class="small-title"><a href="unos.php">UNOS</a></h2>
      <h2 class="small-title"><a href="registracija.php">REGISTRACIJA</a></h2>
    </div>
  </header>
  <hr>

  <section>
    <h2 class="section-title"><?php echo $category; ?></h2>
    <div class="row">
      <?php
      $i = 1;
      while ($row = mysqli_fetch_array($result)) {
        echo '<a href="clanak.php?id=' . $row['id'] . '" class="box-link">';
        echo '<div class="box">';
        echo '<img src="' . UPLPATH . $row['slika'] . '" alt="Article ' . $i . '">';
        echo '<div class="article-content">';
        echo '<p class="mnaslov">' . $row['naslov'] . '</p>';
        echo '<p class="subtext">' . $row['kategorija'] . ' - Publie il y a ' . $i . ' heures</p>';
        echo '</div>';
        echo '</div>';
        echo '</a>';
        $i++;
      }
      ?>
    </div>
  </section>

  <footer>
  <p>Copyright 2019 Morgenpost Verlad GmbH</p>
  </footer>
</body>
</html>
